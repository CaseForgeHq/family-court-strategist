# Case Forge workspace

Read `CASE-FORGE.md` before working in this folder. Preserve originals, cite sources and review findings with the user.
